﻿using System;

internal class random
{
    internal static int Next()
    {
        throw new NotImplementedException();
    }
}