﻿using Loja_de_Instrumentos.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Loja_de_Instrumentos.Controllers
{
    public class InstrumentosController : Controller
    {
        

        public IActionResult Index(string search, string type, bool order = false)
        {
            
            List<Instrumento> Instrumentos()
            {
                if (type == "guitarra")
                {
                    var guitarras = GetInstruments().OfType<Guitarra>().ToList();
                    var instrumentos = guitarras.OfType<Instrumento>().ToList();
                    return instrumentos;
                }
                else if (type == "violao")
                {
                    var violoes = GetInstruments().OfType<Violao>().ToList();
                    var instrumentos = violoes.OfType<Instrumento>().ToList();
                    return instrumentos;
                }
                else if (type == "bateria")
                {
                    var baterias = GetInstruments().OfType<Bateria>().ToList();
                    var instrumentos = baterias.OfType<Instrumento>().ToList();
                    return instrumentos;
                }
                else
                {
                   var instrumentos = GetInstruments();
                   return instrumentos;
                }  
            }

            ViewBag.msg = "";
            ViewBag.total = Instrumentos().Count;
            ViewBag.sum = Instrumentos().Sum(x => x.Price);
            ViewBag.maxprice = Instrumentos().Find(x => x.Price == Instrumentos().Max(x => x.Price)).Brand + " " + Instrumentos().Find(x => x.Price == Instrumentos().Max(x => x.Price)).Model;

            ViewBag.order = order;
            if (order)
            {
                ViewBag.msg = "";
                ViewBag.total = Instrumentos().Count;
                ViewBag.sum = Instrumentos().Sum(x => x.Price);
                ViewBag.maxprice = Instrumentos().Find(x => x.Price == Instrumentos().Max(x => x.Price)).Brand + " " + Instrumentos().Find(x => x.Price == Instrumentos().Max(x => x.Price)).Model;
                var orderBy = Instrumentos().OrderBy(x => x.Model).ToList();
                return View(orderBy);
            }
            
            return View(search == null ? Instrumentos() : Instrumentos().FindAll(x => x.Brand.ToUpper().Contains(search.ToUpper()) || x.Model.ToUpper().Contains(search.ToUpper())));
        }
    
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(Instrumento instrumento)
        {
            List<Instrumento> instrumentos = GetInstruments();
            instrumento.Id = instrumentos.Last().Id + 1;
            instrumentos.Add(instrumento);

            ViewBag.msg = "Instrumento " + instrumento.Brand + " " + instrumento.Model + " criado com sucesso";
            ViewBag.order = false;
            ViewBag.total = instrumentos.Count;
            ViewBag.sum = instrumentos.Sum(x => x.Price);
            ViewBag.maxprice = instrumentos.Find(x => x.Price == instrumentos.Max(x => x.Price)).Brand + " " + instrumentos.Find(x => x.Price == instrumentos.Max(x => x.Price)).Model;
            return View(nameof(Index), instrumentos);
        }

        public IActionResult Read(int? id)
        {
            Instrumento instrumento = GetInstruments().FirstOrDefault(x => x.Id == id);
            return instrumento != null ? View(instrumento) : RedirectToAction(nameof(Index));
        }

        public IActionResult Update(int? id)
        {
            Instrumento instrumento = GetInstruments().FirstOrDefault(x => x.Id == id);
            return instrumento != null ? View(instrumento) : RedirectToAction(nameof(Index));
        }
        [HttpPost]
        public IActionResult Update(Instrumento instrumentoUpdate)
        {
            List<Instrumento> instrumentos = GetInstruments();
            Instrumento instrumento = instrumentos.FirstOrDefault(x => x.Id == instrumentoUpdate.Id);
            if (instrumento == null) return RedirectToAction(nameof(Index));

            var indice = instrumentos.IndexOf(instrumento);
            instrumentos[indice] = instrumentoUpdate;

           
            ViewBag.msg = "Instrumento " + instrumento.Brand + " " + instrumento.Model + " editado com sucesso";
            ViewBag.order = false;
            ViewBag.total = instrumentos.Count;
            ViewBag.sum = instrumentos.Sum(x => x.Price);
            ViewBag.maxprice = instrumentos.Find(x => x.Price == instrumentos.Max(x => x.Price)).Brand + " " + instrumentos.Find(x => x.Price == instrumentos.Max(x => x.Price)).Model;
            return View(nameof(Index), instrumentos);
        }
        public IActionResult Delete(int? id)
        {
            List<Instrumento> instrumentos = GetInstruments();
            Instrumento instrumento = instrumentos.FirstOrDefault(x => x.Id == id);
            if (instrumento != null)
            {
                
                ViewBag.msg = "Instrumento " + instrumento.Brand + " " + instrumento.Model + " removido com sucesso";
                ViewBag.order = false;
                ViewBag.total = instrumentos.Count;
                ViewBag.sum = instrumentos.Sum(x => x.Price);
                ViewBag.maxprice = instrumentos.Find(x => x.Price == instrumentos.Max(x => x.Price)).Brand + " " + instrumentos.Find(x => x.Price == instrumentos.Max(x => x.Price)).Model;
                
                instrumentos.Remove(instrumento);
                return View(nameof(Index), instrumentos);
            }
            
            return instrumento == null ?
                NotFound() :
                View(nameof(Index));
        }
        
        public IActionResult Confirm(int? id)
        {
            Instrumento instrumento = GetInstruments().FirstOrDefault(x => x.Id == id);
            return instrumento != null ? View(instrumento) : RedirectToAction(nameof(Index));
        }

        //public IActionResult Order(string search)
        //{
        //    List<Instrumento> instrumentosByName = Instrumentos().OrderBy(x => x.Model).ToList();
        //    ViewBag.msg = "";
        //    ViewBag.order = true;
        //    ViewBag.total = instrumentosByName.Count;
        //    ViewBag.sum = instrumentosByName.Sum(x => x.Price);
        //    ViewBag.maxprice = instrumentosByName.Find(x => x.Price == instrumentosByName.Max(x => x.Price)).Brand + " " + instrumentosByName.Find(x => x.Price == instrumentosByName.Max(x => x.Price)).Model;

        //    return View(nameof(Index), search == null ? instrumentosByName : instrumentosByName.FindAll(x => x.Brand.ToUpper().Contains(search.ToUpper()) || x.Model.ToUpper().Contains(search.ToUpper())));
        //}
        public IActionResult Guitarra()
        {
            List<Instrumento> guitarras = GetInstruments();

            return View(nameof(Index), guitarras);
        }
       
        List<Instrumento> GetInstruments()
        {
            List<Instrumento> instruments = new();
            

            instruments.Add(new Guitarra("Fender", "Stratocaster")
            {
                Id = 1,
                Description = "A Fender Stratocaster é um modelo de guitarra elétrica desenhada por Leo Fender, " +
                "George Fullerton e Freddie Tavares em 1954.",
                Price = 9999.99,
                Link = "https://images.musicstore.de/images/1280/fender-75th-anniversary-commemorative-stratocaster_1_GIT0055575-000.jpg"
            });
            instruments.Add(new Guitarra("Gibson", "SG")
            {
                Id = 2,
                Description = "Gibson SG é um dos mais conhecidos modelo de guitarra " +
                "elétrica, de corpo sólido surgido no começo dos anos 60.",
                Price = 12999.99,
                Link = "https://reference.vteximg.com.br/arquivos/ids/285617-1000-1000/frontal.jpg?v=636286502567700000"
            });
            instruments.Add(new Violao("Martin", "DJR2E")
            {
                Id = 3,
                Description = "A C.F. Martin & Company é uma fabricante de violões dos Estados Unidos, estabelecida" +
                " em 1833 por Christian Frederick Martin, que nasceu em 1796 na cidade de Markneukirchen na Alemanha.",
                Price = 5999.99,
                Link = "https://images-na.ssl-images-amazon.com/images/I/815LrvftyWL.jpg"
            });
            instruments.Add(new Violao("Epiphone", "DR-100")
            {
                Id = 4,
                Description = "The DR-100 features chrome hardware, a 25.5' scale, 1.68' nut width, set mahogany neck with dot inlays, mahogany body and select spruce top.",
                Price = 1499.99,
                Link = "https://sc1.musik-produktiv.com/pic-100009980xl/epiphone-dr-100-na.jpg"
            });
            instruments.Add(new Guitarra("Gibson", "Les Paul")
            {
                Id = 5,
                Description = "Gibson Les Paul é uma guitarra de corpo sólido que começou a ser vendida em 1952.",
                Price = 24999.99,
                Link = "https://x5music.vteximg.com.br/arquivos/ids/183227-1920-1920/GUITARRA-GIBSON-TRADITIONAL-LESPAUL-Honey-Burst-COM-CASE.jpg"
            });
            instruments.Add(new Bateria("Pearl", "EXPORT EXX725S")
            {
                Id = 6,
                Description = "As lendas de amanhã tocam com a Pearl Export hoje. A Export Series agora incorpora a tecnologia de suspensão Pearl's S.S.T., montagem de tom Opti-Loc e acabamento Grindstone Sparkle.",
                Price = 5199.99,
                Link = "https://x5music.vteximg.com.br/arquivos/ids/170212-1920-1920/EXX725S-708.jpg"
            });
                

            return instruments;
            
        }

    }
}
