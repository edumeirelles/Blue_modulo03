﻿using Loja_de_Instrumentos.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Loja_de_Instrumentos.Controllers
{
    public class InstrumentosController : Controller
    {
        public IActionResult Index(string search)
        {
            List<Instrumento> instrumentos = GetInstruments();

            ViewBag.msg = "";
            ViewBag.total = instrumentos.Count;
            ViewBag.sum = instrumentos.Sum(x => x.Price);
            ViewBag.maxprice = instrumentos.Find(x => x.Price == instrumentos.Max(x=> x.Price)).Brand +" "+ instrumentos.Find(x => x.Price == instrumentos.Max(x => x.Price)).Model;

            return View(search == null ? instrumentos : instrumentos.FindAll(x => x.Brand.Contains(search) || x.Model.Contains(search)));
        }
    
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(Instrumento instrumento)
        {
            List<Instrumento> instrumentos = GetInstruments();
            instrumento.Id = instrumentos.Last().Id + 1;
            instrumentos.Add(instrumento);
            ViewBag.msg = "Instrumento cadastrado com sucesso!";
            return View("Index", instrumentos);
        }
        List<Instrumento> GetInstruments()
        {
            List<Instrumento> instruments = new();

            instruments.Add(new Instrumento { Id = 1,Type = "Guitarra", Brand = "Fender", Model = "Stratocaster",
                Description= "A Fender Stratocaster é um modelo de guitarra elétrica desenhada por Leo Fender, " +
                "George Fullerton e Freddie Tavares em 1954.", Price = 9999.99, Link = "https://images.musicstore.de/images/1280/fender-75th-anniversary-commemorative-stratocaster_1_GIT0055575-000.jpg"});
            instruments.Add(new Instrumento { Id = 2, Type = "Guitarra", Brand = "Gibson", Model = "SG", 
                Description = "Gibson SG é um dos mais conhecidos modelo de guitarra " +
                "elétrica, de corpo sólido surgido no começo dos anos 60.", Price=12999.99, Link = "https://reference.vteximg.com.br/arquivos/ids/285617-1000-1000/frontal.jpg?v=636286502567700000"
            });

            return instruments;
        }
    }
}
